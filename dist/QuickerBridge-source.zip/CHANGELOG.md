# QuickerBridge — version history

## What's new in 1.01

- **Truck load fraction FT for steel grid, aluminum and transverse wood decks on steel
  girders** (S6-25 5.6.7, Tables 5.8 to 5.12; classes C and D: A5.3.4, Tables A5.3.4,
  5.9 and A5.3.5). Grid thickness (< 100 mm or not), laminated wood thickness
  interpolated between 140 and 290 mm, wood plank decks. γc = 1 and no γe except the
  aluminum γc of Tables 5.10 and 5.11; non-skewed bridges only (Fs = 1.0). The
  exterior-girder shear uses the lever rule (one truck, wheel line at a set distance from
  the curb, 0.6 m by default) and is never less than the interior-girder shear.
- **Results layout:** V, M, deflection and the reactions (now about half as high) fit a
  1920 × 1080 screen; EI moved below the reactions. One toolbar for the result views and
  the display modes. The beam sketch is drawn at its real height, so its supports sit on
  the support lines of the diagrams.
- **Sections tab:** one value per line with compact boxes; the zones of each span in a
  compact table under a bar drawn to scale.
- **Code:** `app.js` and `styles.css` split by responsibility into `dist/js/` and
  `dist/css/` (no build step; same order of execution and cascade). The portable HTML
  still inlines everything in one file.
- README reduced to one page; the version history moved to this file.

## What's new in 1.0

- **Automatic mesh, no "Numerical precision" setting.** The truck now moves by Lmin/80, bounded to 0.05–0.25 m (Lmin = shortest span), plus the exact positions where an axle crosses a station; 48 influence samples per member (already relative to its length) and 480 deflection points per span. A convergence study (`tests/mesh_study.py`, six bridges from 2 × 10 m to 60-80-60 m, against a 0.02 m / 192-sample reference) shows that the travel step is the only parameter that matters: every envelope (M, V, deflection, reactions) stays within 0.02 %, at the speed of the former Standard mode. Older projects open unchanged (their Standard / Fine choice is ignored).
- **Deck cut:** the hinge option and the launching/demolition paragraph are removed; a cut keeps both parts, or only the left or right one. Projects saved with a hinge keep it (flagged) until "Cut" is chosen.
- **1920 × 1080 layout:** the workspace uses the whole width; the header is slimmer, without the "continuous beam" subtitle, with the preliminary-values notice and a GitHub link (top right); the four headline values take two lines; the diagram height follows the window height (three diagrams visible at 100 % zoom on a 1080p screen).
- **Windows inside the screen:** every floating window (section properties, stresses, FT, calculation sheet, method) is capped to the screen height, scrolls inside and slides back up when its content grows. On a wide screen the section properties window uses three input columns and two result columns, so the composite case fits without scrolling.
- Project schema 17.

## What's new in 0.9.99

- **Deck cut or hinge at any station** (Geometry tab, "Deck cut"): launching and demolition stages. A **cut** (saw cut) splits the deck into two independent beams, neither V nor M crosses it; a **hinge** carries the shear with M = 0 (it does not model a sawn deck). With a cut, keep both parts, or only the left or the right one: the removed part has no stiffness, no load and no reaction (hatched on the beam and the diagrams). Each part kept must stand on its own supports; otherwise a clear "mechanism" message. Envelopes, influence lines, governing live load, thermal cases and vibration modes take the joint into account (PyCBA: free node, released member or zero-stiffness link).
- **Section inertia, simpler:** for a steel or NEBT girder the analysis uses the girder alone, the composite 3n or 1n section (M+), or the cracked I′ (M−, steel + bars). The inertia multiplier M is no longer entered (it is I config / I girder, shown). Projects with M ≠ 1 keep it, flagged, until another choice. The "two spans" example now has a slab: S1 composite 1n (3.91, was M = 3.92), S2 cracked I′ (1.09, was 1.12).
- **Resistance tab:** no more Mr/Vr on the main Envelope and Governing live load diagrams and no "Determine the resistance" switch; the maximum D/C ratios and the **Calculation sheet** button are at the bottom of the panel.
- **Calculation sheet rebuilt:** V and M diagrams stacked, with Vr and Mr (dashes), red bands where exceeded, governing ratios, station cursor (click, drag, ← →); choice of the effects compared: **permanent loads, live load or both**; compact D/C chips; on the left, section, **section properties** and **materials and factors**; on the right, the **effects at the station by load stage** (M and V: self-weight, "girder alone" loads, other permanent loads, live max/min) then the calculations with **one value per row**.
- **Composite girder:** no lateral-torsional buckling in M− classes 1-2 (compression flange braced), and Frd (10.10.4.4) for the steel girder alone only.
- **Section properties window:** an **OK** button validates the section; the bridge is recalculated then if the slab changes a composite analysis inertia. The analysis inertia is chosen only on the section card (4 types once the slab is defined).
- **Fix (found after the first 0.9.99 push):** the cached analysis basis was rebuilt without the slab, so a composite inertia (3n, 1n, I′) fell back to the girder alone. Checked against the force method on the composite example: permanent-load M− = −2 101 kN·m (independent −2 102; it showed −2 898 before the fix).
- **Floating windows** resize from every edge and corner.
- Project schema 16.

## What's new in 0.9.98

- **Resistance along the bridge.** The Résistance tab no longer asks for Mf, Vf or resistance factors: at every station it takes the factored effects of the analysis (permanent + live loads, factors as entered: Mf+ = max(M max, 0), Mf− = max(−M min, 0), Vf = max |V|) and the section in force there, tapers included. No sub-tabs and no results group. The first control is **"Determine the resistance"**: Mr+, Mr− and ±Vr are drawn as dashed curves around the M and V envelopes (Envelope and Governing live load views, not Δ ranges or influence lines), with the governing station, its D/C, red bands where the envelope exceeds the resistance and the values under the cursor. The panel shows the maximum D/C of M+, M−, V and the V-M interaction with their location (click: calculation sheet at that station).
- **Resistance type per section.** A list of the girder sections with two check boxes, Composite and Steel alone (composite needs the slab of "Section properties").
- **Steel girder alone (S6-25 10.10).** M+ and M− with lateral-torsional buckling over the unbraced length L (default 6000 mm, the only input), ω2 = 1: Mu with βx (C10.10.2.3), B1, B2, J, Cw; classes 1-2 with Mp, class 3 with My = Fy min(S); class 4 web: Mr × Frd (10.10.4.4) computed for the Mf of each station; class 4 flange: Se (10.10.3.4). Reproduces the author's sheet: βx −852 mm, B1 −2.1, B2 2.8, Mu 8 151 kN·m, My 5 060, Mr 4 567, Frd 0.992, Mr′ 4 531 kN·m, Mf 4 500 → 99.3 %.
- **Class = worst of the three plates** (top flange, bottom flange, web; composite web h/w, girder alone 2dc/w). Class 4 in a composite girder: class 3 rules, flagged.
- **Composite M− class 3:** Fcr of the bottom flange from lateral-torsional buckling over L (10.10.3.3); Mfd is the girder-alone part of the permanent moment (self-weight and "girder alone" loads); the D/C uses an equivalent Mr = Mfd + the largest composite moment meeting a), b), c).
- **V-M interaction (10.10.5.2)** computed for stiffened webs relying on the tension field (h/w > 502 √(kv/Fy)): 0.727 Mf/Mr + 0.455 Vf/Vr ≤ 1, with the larger of the M+ and M− ratios (envelopes: conservative).
- **Calculation sheet** in a wide floating window: station picker on a D/C strip along the bridge (click, drag, ← →, ◀ ▶ or x), recap of effects, resistances and ratios on top, compact blocks side by side (section and class, shear and interaction, M+, M−).
- **Evaluation levels for the CL-625 only** (the CL-750-QC is not an evaluation vehicle; older projects return to its design loads). Road classes C and D are one option (q = 7 kN/m) and the evaluation class follows the FT road class (A/B, C/D).
- **Integral abutments:** the fixed-end moment is labelled **Me** (diagrams, influence lines, Excel); Mr is kept for the moment resistance.
- Project schema 15 (the v0.9.97 resistance inputs are dropped).

## What's new in 0.9.97

- **Resistance tab (new).** A fourth model tab, right of Loads, with a first sub-tab "Steel girder": factored resistance of a composite steel plate girder to CSA S6-25 Section 10. Section class (10.9.2.1: top flange and web in M+, bottom flange and web in M−); Mr+ fully plastic (10.11.5.2, plastic neutral axis in the slab or in the steel) or class 3 (10.11.6.2, compressed web depth against 850 w/√Fy, Figure 10.8 beyond); Mr− plastic for classes 1–2 (10.11.5.3.1, braced) or elastic stresses for class 3 (10.11.6.3.1: Mfd on the steel, Mfsd + Mfl on steel + bars); Vr (10.10.5.1, stiffener spacing a or unstiffened web, flag when Vf > 0.6 Vr). Geometry, slab and bars come from the section and its "Section properties" slab; Mf+, |Mf−| and Vf are entered or taken from the current envelope. D/C bars in the panel; a floating calculation sheet lists every intermediate value. Reproduces the author's validation sheet exactly (Mr+ 17 494 kN·m, 62.9 %; Vr 2 602 kN, 92.2 %). Display only: never changes the analysis. Steel girder alone and class 4: coming.
- **Evaluation levels (S6-25 Section 14).** CL-625 and CL-750-QC take an optional evaluation level: 1 (CL1-W, 5 axles), 2 (CL2-W, axles 1–4, 0.76 W) or 3 (CL3-W, axles 1–3, 0.48 W), W = 625 or 750 kN, axles 0.08, 0.2, 0.2, 0.28, 0.24 W (Figure 14.1). Lane load: 80 % of the axles of the level plus q of the road class (A 9, B 8, C/D 7 kN/m). Under evaluation, the MTQ 63/80 % automatic fraction is off.
- **Pedestrian load, S6-25 expression.** p = 4.25 (0.5 + √(5/s)) kPa, at most 4.25 kPa, s the total loaded length; the editable coefficients of 0.9.96 are removed. The table follows the tributary width as it is typed; the subsection title no longer shows a load value.
- **Lane load placement.** Always on the spans that increase each effect (the 0.9.96 default); the option and its explanations are removed, older projects open with it.
- **Diagram labels.** Shear and deflection show the maximum and minimum of every span, in the envelope and in Δ ranges, like the moments.
- **Governing live load.** A tip above the diagrams says that any diagram can be clicked at any station to see the live load producing that effect (can be hidden).
- **Integral abutment springs.** The help explains the degree of fixity: k / (k + Σ 3EI/L of the adjacent spans), i.e. the relative stiffness of the spring and of the superstructure.

## What's new in 0.9.96

- **Lane load where it increases the effect.** S6 commentary C3.8.4.1: the truck axles and the uniformly distributed load are applied only where they increase the total load effect. The lane UDL now loads, for every response, only the spans whose contribution has the sign sought (new default, "Spans increasing the effect"). Options: "Influence-line parts" (partial spans, where the influence line has that sign) and "Whole bridge" (method up to 0.9.95). The "Governing live load" view draws the loaded spans. Older projects open with the new default.
- **Pedestrian load (S6 3.8.9).** New "Pedestrian load" subsection in Loads, used instead of the vehicle (never both). p = a − s/b kPa between p min and p max, with s the total loaded length; the defaults are those of S6-19 (5 − s/30, 1.6 to 4.0 kPa) until the S6-25 expression is confirmed, and every coefficient is editable. The tributary width is the slab effective width when a slab is defined, else 2000 mm (editable). Every combination of loaded spans (2^n − 1) is evaluated, so the envelope follows the most critical arrangement. Option: envelope with the maintenance vehicle, which is an alternative, never added to the pedestrians. No dynamic allowance, axle factor or FT; the live load factor applies. A click on the diagrams shows the governing arrangement (loaded spans, s, p, w).
- **Names.** "Governing truck" becomes "Governing live load"; the French case tabs read "Vive" and "Permanente + vive". The bilinear gradient is "type B superstructure", 30 °C in the slab by default (was 35). The S6-25 badge is removed from the FT subsection and window titles.
- **FT tables.** Exterior girder shear: one row for FT, then one for FT × Fs (both limit states). Le has two rows: its expression (0,75 L, 0,20 (L1+L2)…) and its numeric application (0,75 × 34,80 = 26,100).
- **Diagram labels.** A plateau (constant shear of an imposed deformation) is labelled once. Moments always show the M+ maximum of every span and the M− at every pier, in the envelope and in Δ ranges; Δ ranges use the same labels as the envelope.
- **Language and Excel.** The interface opens in the browser language (French or English) when no choice was saved. The Excel file name holds the model name, QuickerBridge version and export date; the Model sheet repeats the name and the export date and time.
- **FT flag.** "S6-25 FT applied: values per girder" now sits on the disclaimer line instead of overlapping the beam drawing.

## What's new in 0.9.95

- **Results header as a band.** The five analysis cases (Dead, Live, Dead + live, Imposed deformation, Vibration modes) form one band on top of the beam drawing. The beam drawing keeps only the model name: no heading, no load caption, no section inset. The vibration-mode drawing now has the same length as the others.
- **Display tabs.** Envelope · Δ ranges · Governing truck · Influence lines. Δ ranges is a tab (V, M and δ only, no EI or reactions). Governing truck shows the arrangement of the largest positive moment (click any extreme for another one); the manual position, reverse and animation row is removed. Influence lines no longer repeat the reaction diagram. The "min / max envelope" legend is removed.
- **Peak labels.** Every independent part of the bridge (separated by a simple span or a split pier) shows its own extremes of V, M and deflection, and any peak within 0.5 % of the overall extreme is labelled too, so symmetry is visible at a glance. The four headline values are rounded up, without decimals except one for the deflection.
- **FT in its own window.** "Set FT…" opens a floating window, like the stresses. FT is always computed there; the switch "Apply S6-25 FT to the envelopes" in Loads (off by default) applies it. The zone table has an Fs row. No "DVE limited to 3.0 m" alert.
- **Lighter interface.** No stiffness-step warning or red circles on EI; no uplift warning for the live load alone; examples show their titles only; mode names in the singular. The stress preview on hover is off by default (a box next to "σ Stresses"). "Focus diagrams" is replaced by an arrow that collapses the model panel. The Examples menu opens above every window.
- **Readability and keyboard.** Secondary text, chart scales and series names reach WCAG AA contrast; functional text is at least 11 px. File and Examples menus work with the arrow keys and Escape; tabs and segmented controls expose their state to screen readers; a focused diagram steps through stations with ← → (Shift: 10 stations, Home / End) and reads the values aloud. Flatter surfaces (no gradients or side stripes), the disclaimer inside the results, and "S6-25 FT applied: values per girder" above the headline values when FT is applied.

## What's new in 0.9.9

- **Work protection.** Reset asks first when the model has unsaved changes (save, reset without saving, or cancel). Leaving the page with unsaved changes asks for confirmation. The unsaved model is kept in this browser and offered back at the next start ("Unsaved model found": Restore / Dismiss). Ctrl+Z / Ctrl+Y undo and redo model changes (edits, opened files, examples, reset), also from **File → Undo**.
- **Analysis type apart from the load case.** The results header has two controls: **Static / Vibration modes**, then the four load cases (Dead, Live, Dead + live, Imposed deformation). The load case is kept while the modes are shown. The header wraps instead of overflowing on medium and narrow screens.
- **Clearer errors.** An invalid number shows its message (e.g. the allowed range) right under the field while it is edited. The stress window no longer shows valid station and S3 values as errors. The Excel item says why it is unavailable (engine loading, calculation running, invalid values).

## What's new in 0.9.8

- **Faster.** First analysis of a 6-span non-prismatic bridge about 40 times faster (cached Gauss rule in PyCBA); each live-load update 4 to 5 times faster (every axle subset handled at once, exactly; "axle exactly on a station" positions evaluated for that station only). Envelope differences below 0.01 %. Changes made during an analysis are merged into one update of the latest model, after a wait that adapts to the previous analysis time.
- **Split pier** (Geometry tab, support type): deck joint over a pier with two bearings. The spans on either side are independent; the diagram, the station table and the Excel export give two reactions (L / R).
- **Sections.** Direct EI given as EI, as f′c and γc (computed E) with I, or as E (MPa) and I. NEBT girders: f′c (50 MPa) and γc (24.5 kN/m³) → E shown; γc also scales the self-weight. For a girder with a slab, the analysis inertia can come straight from the 1n, 3n or I′ composite section: M is then computed and greyed out (never applied twice). Default slab 225 mm. An unused section can be removed.
- **Interface.** QuickerUnits-style inputs (thousands separator, decimal comma in French, calculations allowed: `2*17.4`), model name in evidence (also in the beam frame), **File** menu (Open, Save, Compare, Excel; Ctrl+O, Ctrl+S) and **Examples** menu (4 anonymous bridges, FT not applied). The beam sketch names the section of every zone. The imposed-deformation drawings show the actual girder (steel, NEBT or EI).
- FT: the overall width B = (N − 1)·S + 2·Sc is highlighted together with the curb (B − Wc)/2.

## What's new in 0.9.7

- **MTQ automatic fraction (CL-750-QC).** On by default: the 12.6 kN/m lane load goes with the truck at 63 % or 80 % of its axles per response, as in MTQ Info-structures A2023-05 (63 % for M+ outside the M− zones of the supports, shear, single-span bridges and reactions without deck continuity; 80 % for M−, M+ in the M− zones over piers, reactions at continuous piers and deflections). Untick it to choose 63 % or 80 % by hand. The lane load always covers the whole deck (S6 bumper-to-bumper case), as before. Support reactions are now a fifth diagram with arrows at the supports, replacing the table below the diagrams.
- The vehicle always travels in both directions; the "travel direction" option is removed (older files open unchanged).
- Up to 7 spans. The section at the cursor (girder, slab, or an "EI" box) is drawn in the beam frame.
- "Thermal" becomes **Imposed deformation**: thermal gradient (with an illustrated profile), slab shrinkage (250 × 10⁻⁶ by default) and slab creep (ε = φ σc / Ec), each analysed alone, on the long-term k·n composite section (k = 3 by default).
- Stresses: the hover preview shows the top-bar stress in both cases, no slab value, and the M max / M min legend; the full window has a beam sketch with a cursor (click or drag to move the station).

## What's new in 0.9.6

- Audit fixes: the v0.9.5 constant support section is removed (it overrode the non-prismatic zones; older files still open); bars must lie inside the slab; the stress load stages are saved with the project; one project schema (9) for Python and the browser.
- NEBT girders: section properties (tabulated A, I, yb, h; composite with n = Eg/Ec and bars m = Es/Eg; negative region I′) and stress diagrams like steel girders. A bridge with NEBT girders cannot be non-prismatic.
- Stresses: instant hover preview from one all-stations calculation, fixed scale from the bridge extreme tension and compression, values in MPa on the drawing coloured by sign, S1–S5 marked in the full window.
- FT tab always visible, no axle factor by default. Slab FLS shear n ≥ 2 follows each printed table (A/B: 3.20 + 0.10 Le; C/D: 3.20 + 0.10/Le). The Excel FT sheet lists every parameter.
- Diagram readout in the colour of each diagram, values next to the dots; "Method and assumptions" window in the header; explanation of standard vs fine precision.
